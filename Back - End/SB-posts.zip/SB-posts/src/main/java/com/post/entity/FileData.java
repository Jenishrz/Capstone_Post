package com.post.entity;

import java.util.Arrays;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_file")
public class FileData {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long fileId;
	
	private String fileName;
	
	private String fileType;
	
	@Lob
	private byte[] fdata;

	public FileData() {
		super();

	}

	public FileData(String fileName, String fileType, byte[] data) {
		super();
		
		this.fileName = fileName;
		this.fileType = fileType;
		this.fdata = data;
	}

	public long getFileId() {
		return fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public byte[] getData() {
		return fdata;
	}

	public void setData(byte[] data) {
		this.fdata = data;
	}
	

}
