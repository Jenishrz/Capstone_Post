package com.post.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.post.entity.User;

//public interface UserRepo extends JpaRepository<User, Long> {


public interface UserRepo
{
		public void updateUser(User user);
		
}
