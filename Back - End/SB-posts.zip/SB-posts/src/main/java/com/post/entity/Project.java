package com.post.entity;

import java.sql.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity 

@Table(name = "tbl_project") 

public class Project { 

    @Id 

    @GeneratedValue(strategy = GenerationType.IDENTITY) 

    @Column(name = "project_id") 

    private Long projectId; 

  

    @Column(name = "project_name") 

    private String projectName; 

  

    @Column(name = "start_date") 

    private Date startDate; 

  

    @Column(name = "end_date") 

    private Date endDate; 

  

    @ManyToOne 

    @JoinColumn(name = "department_id") 

    private Department department; 

    
public Project() { 

super(); 

} 

  

public Project(Long projectId, String projectName, Date startDate, Date endDate, Department department

) { 

super(); 

this.projectId = projectId; 

this.projectName = projectName; 

this.startDate = startDate; 

this.endDate = endDate; 

this.department = department; 



} 

  

public Long getProjectId() { 

return projectId; 

} 

  

public void setProjectId(Long projectId) { 

this.projectId = projectId; 

} 

  

public String getProjectName() { 

return projectName; 

} 

  

public void setProjectName(String projectName) { 

this.projectName = projectName; 

} 

  

public Date getStartDate() { 

return startDate; 

} 

  

public void setStartDate(Date startDate) { 

this.startDate = startDate; 

} 

  

public Date getEndDate() { 

return endDate; 

} 

  

public void setEndDate(Date endDate) { 

this.endDate = endDate; 

} 

  

public Department getDepartment() { 

return department; 

} 

  

public void setDepartment(Department department) { 

this.department = department; 

} 

  





  

    

} 
