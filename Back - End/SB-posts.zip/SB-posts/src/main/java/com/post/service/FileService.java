package com.post.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.post.entity.FileData;
import com.post.repository.FileRepo;

@Service
public class FileService {
	
	@Autowired
	private FileRepo dbrepo;
	public FileData storeFile(MultipartFile file)throws IOException{
		
		String filename = StringUtils.cleanPath(file.getOriginalFilename());
		FileData fData = new FileData(filename, file.getContentType(), file.getBytes());
		return dbrepo.save(fData);
		
	}

}
