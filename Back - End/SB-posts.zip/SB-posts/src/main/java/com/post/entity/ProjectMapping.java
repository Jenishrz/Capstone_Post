//package com.post.entity;
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.ManyToOne;
//import jakarta.persistence.Table;
//
//@Entity 
//
//@Table(name = "tbl_project_mapping") 
//
//public class ProjectMapping { 
//
//    @Id 
//
//    @GeneratedValue(strategy = GenerationType.IDENTITY) 
//
//    @Column(name = "mapping_id") 
//
//    private Long mappingId; 
//
//  
//
//    @ManyToOne 
//
//    @JoinColumn(name = "user_id") 
//
//    private User user; 
//
//  
//
//    @ManyToOne 
//
//    @JoinColumn(name = "project_id") 
//
//    private Project project; 
//
//  
//
//    @ManyToOne 
//
//    @JoinColumn(name = "department_id") 
//
//    private Department department; 
//
//  
//
//    @ManyToOne 
//
//    @JoinColumn(name = "region_id") 
//
//    private Region region; 
//
//  
//
//    @Column(name = "project_status") 
//
//    private String projectStatus; 
//
//  
//
//public ProjectMapping() { 
//
//super(); 
//
//} 
//
//  
//
//public ProjectMapping(Long mappingId, User user, Project project, Department department, Region region, 
//
//String projectStatus) { 
//
//super(); 
//
//this.mappingId = mappingId; 
//
//this.user = user; 
//
//this.project = project; 
//
//this.department = department; 
//
//this.region = region; 
//
//this.projectStatus = projectStatus; 
//
//} 
//
//  
//
//public Long getMappingId() { 
//
//return mappingId; 
//
//} 
//
//  
//
//public void setMappingId(Long mappingId) { 
//
//this.mappingId = mappingId; 
//
//} 
//
//  
//
//public User getUser() { 
//
//return user; 
//
//} 
//
//  
//
//public void setUser(User user) { 
//
//this.user = user; 
//
//} 
//
//  
//
//public Project getProject() { 
//
//return project; 
//
//} 
//
//  
//
//public void setProject(Project project) { 
//
//this.project = project; 
//
//} 
//
//  
//
//public Department getDepartment() { 
//
//return department; 
//
//} 
//
//  
//
//public void setDepartment(Department department) { 
//
//this.department = department; 
//
//} 
//
//  
//
//public Region getRegion() { 
//
//return region; 
//
//} 
//
//  
//
//public void setRegion(Region region) { 
//
//this.region = region; 
//
//} 
//
//  
//
//public String getProjectStatus() { 
//
//return projectStatus; 
//
//} 
//
//  
//
//public void setProjectStatus(String projectStatus) { 
//
//this.projectStatus = projectStatus; 
//
//} 
//
//  
//
//} 
